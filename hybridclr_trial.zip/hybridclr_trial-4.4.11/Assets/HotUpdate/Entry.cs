﻿using HybridCLR;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using UnityEngine;


public static class Entry
{
    public static async UniTask UniTaskTest()
    {
        await Task.Delay(1000);
        Debug.LogError("UnitTask");
    }
    
    public static async Task TaskTest()
    {
        await Task.Delay(1000);
        Debug.LogError("TaskTestPass");
    }

    public static async void TestCrash()
    {
        Debug.Log("StartUniTestCrashTest...");

        Debug.Log("First Test[Task]...");
        await TaskTest();
        
        
        await Task.Delay(1000);
        Debug.Log("Second Test[UniTask]...");
       
        await Task.Delay(500);
     
        Debug.LogError("Going To Crash After 1s");
            
        await Task.Delay(1000);
        UniTaskTest().Forget();
    } 

    
    public static void Start()
    {
        TestCrash();
    }
    
}